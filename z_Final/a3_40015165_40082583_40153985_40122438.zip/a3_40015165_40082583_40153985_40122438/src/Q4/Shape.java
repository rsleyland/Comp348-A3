public interface Shape {
    int getId();
    String getName();
    double getPerimeter();
    double getArea();
}
